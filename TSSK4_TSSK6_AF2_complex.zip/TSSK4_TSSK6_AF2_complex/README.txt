TSSK4 x TSSK6 — AlphaFold2-Multimer predicted complex
======================================================

WHAT THIS IS
  A predicted heterodimer of two paralogous testis-specific serine/threonine
  kinases, folded with AlphaFold2-Multimer-v3 (ColabFold, 5 models x 5 seeds =
  25 predictions). This is a computational prediction, NOT experimental evidence
  of a real interaction.

PROTEINS
  Chain A = TSSK4  (UniProt Q6SA08), kinase-domain construct, residues 1-328
  Chain B = TSSK6  (UniProt Q9BXA6), kinase-domain construct, residues 1-273
  Total: 601 residues.

CONFIDENCE (best model = rank_001, model_3_seed_003)
  ipTM       0.589   <- interface confidence
  pTM        0.72
  mean pLDDT 79.2
  For comparison, the three length-matched control pairs folded in the SAME run
  scored ipTM ~0.26-0.27. So the novel pair sits clearly above its controls.

HOW TO READ IT
  ipTM 0.59 is "borderline plausible": above AF2's noise floor and above the
  controls, but below the confident-interface bar (~0.6-0.7). AF2 has no concept
  of when/where a protein is expressed, so it will dock two similar kinase
  domains even if they are spatiotemporally separated in vivo and never actually
  meet. Treat this as a hypothesis to test, not a settled complex.

FILES
  TSSK4_TSSK6_rank001_best.pdb     Best model, unrelaxed coordinates (open in
                                   PyMOL/ChimeraX). Chain A = TSSK4, B = TSSK6.
  TSSK4_TSSK6_rank001_scores.json  Per-residue pLDDT + iptm/ptm for this model.
  TSSK4_TSSK6_pae.png              Predicted Aligned Error plot (look at the
                                   off-diagonal A-vs-B block for interface trust).
  TSSK4_TSSK6_plddt.png            Per-residue confidence plot.
  TSSK4_TSSK6_pae_matrix.json      Full PAE matrix (numeric).
  TSSK4_TSSK6_msa_coverage.png     MSA depth used for the fold.

PROVENANCE
  negaverse project, IDG understudied-kinome novel-prediction set.
  Ranked candidate #13 in out/inductive/novel_idg_verified.tsv (p_interact 0.54).
  Fold run: local-docs/af2_tssk/ (AlphaFold2-multimer-v3, run 2026-07-13).
  "unrelaxed" = no Amber relaxation applied; geometry is raw AF2 output.
